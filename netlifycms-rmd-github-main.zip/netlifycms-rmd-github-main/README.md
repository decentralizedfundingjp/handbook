# Using Netlify CMS with R Markdown

Steps to accomplish this are described [here](https://www.gerkelab.com/blog/2021/04/netlifycms-rmd-ghpages/)
